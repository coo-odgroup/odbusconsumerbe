<?php

namespace App\Repositories;
use Illuminate\Http\Request;
use App\Models\Bus;
use App\Models\Location;
use App\Models\BusOperator;
use App\Models\BoardingDroping;
use App\Models\BusStoppageTiming;
use App\Models\BusType;
use App\Models\BusClass;
use App\Models\SeatClass;
use App\Models\Amenities;
use App\Models\BusSeats;
use App\Models\Seats;
use App\Models\CancellationSlab;
use App\Models\CancellationSlabInfo;
use App\Models\BusContacts;
use App\Models\TicketPrice;
use App\Models\BusScheduleDate;
use App\Models\Booking;
use App\Models\BusSchedule;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Arr;

use DateTime;
use Illuminate\Support\Facades\Log;
use DB;
use Illuminate\Support\Facades\Config;

class ListingRepository
{
    protected $bus;
    protected $location;
    protected $busOperator;
    protected $busStoppageTiming;
    protected $busType;
    protected $busClass;
    protected $seatClass;
    protected $amenities;
    protected $boardingDroping;
    protected $busSeats;
    protected $ticketPrice;
    protected $busScheduledate;
    protected $busSchedule;
    protected $booking;
    
    public function __construct(Bus $bus,Location $location,BusOperator $busOperator,BusStoppageTiming $busStoppageTiming,BusType $busType,Amenities $amenities,BoardingDroping $boardingDroping,BusClass $busClass,SeatClass $seatClass,BusSeats $busSeats,TicketPrice $ticketPrice,BusScheduleDate $busScheduleDate,BusSchedule $busSchedule, Booking $booking)
    {
        $this->bus = $bus;
        $this->location = $location;
        $this->busOperator = $busOperator;
        $this->busStoppageTiming = $busStoppageTiming;
        $this->busType = $busType;
        $this->amenities = $amenities;
        $this->boardingDroping = $boardingDroping;
        $this->busClass = $busClass;
        $this->seatClass = $seatClass; 
        $this->ticketPrice = $ticketPrice;
        $this->busScheduleDate = $busScheduleDate;
        $this->busSchedule = $busSchedule;
        $this->booking=$booking;
     }   

     public function getLocation($request)
     {
        $searchValue = $request['locationName'];
         return $this->location
         ->where('name', 'like', '%' .$searchValue . '%')
         ->where('status','1')  
         ->orWhere('synonym', 'like', '%' .$searchValue . '%')
         ->orderBy('name','ASC')
         ->where('status','1')  
         ->get(['id','name','synonym']);
     }
 
    public function getAll($request)
    { 
       
        $source = $request['source'];
        $destination = $request['destination'];
        $entry_date = $request['entry_date'];
        $entry_date = date("Y-m-d", strtotime($entry_date));

        $sourceID =  $this->location->where("name", $source)->get('id');
        $destinationID =  $this->location->where("name", $destination)->get('id');

        if($sourceID->count()==0 || $destinationID->count()==0)
           return "";
        $sourceID =  $this->location->where("name", $source)->first()->id;
        $destinationID =  $this->location->where("name", $destination)->first()->id;  

        $busDetails = $this->ticketPrice
                ->where('source_id', $sourceID)
                ->where('destination_id', $destinationID)->get(['bus_id','start_j_days']);  
        $records = array();
        $ListingRecords = array();
        foreach($busDetails as $busDetail){
            $busId = $busDetail['bus_id'];
            $jdays = $busDetail['start_j_days'];
            $busEntryPresent =$this->busSchedule->where('bus_id', $busId)
                                ->exists(); 
            if($busEntryPresent==true){
                $busScheduleId = $this->busSchedule->whereIn('bus_id', (array)$busId)->pluck('id');    
                $dates = $this->busScheduleDate
                    ->where('bus_schedule_id', $busScheduleId)           
                    ->pluck('entry_date')->toarray();
                if($jdays>1){
                    $new_date = date('Y-m-d', strtotime('-1 day', strtotime($entry_date)));
                }else{
                    $new_date = $entry_date;
                }
                if(in_array($new_date, $dates))
                {
                    $records[] = $this->bus
                    ->with('busContacts')
                    ->with('busOperator')       
                    ->with('busAmenities.amenities')
                    ->with('busSafety.safety')
                    ->with('BusType.busClass')
                    ->with('busSeats.seats')
                    //->with('seatOpen.seatOpenSeats')
                    ->with('BusSitting')
                    ->with('busGallery')
                    ->with('cancellationslabs.cancellationSlabInfo')
                    ->where('status','1')
                    ->where('id',$busId)
                    ->get();
                } 
            } 
        }
        $records = Arr::flatten($records);
        //return $records;
        foreach($records as $record){
           
            $busId = $record->id; 
            $busName = $record->name;
            $popularity = $record->popularity;
            $busNumber = $record->bus_number;
            $via = $record->via;
            $maxSeatBook = $record->max_seat_book;
            $conductor_number = $record->busContacts->phone;
            $operatorId = $record->busOperator->id;
            $operatorName = $record->busOperator->operator_name;
            $sittingType = $record->BusSitting->name;   
            $busType = $record->BusType->busClass->class_name;
            $busTypeName = $record->BusType->name;
            $ticketPriceDatas = $record->ticketPrice;

            $ticketPriceRecords = $ticketPriceDatas
                    ->where('source_id', $sourceID)
                    ->where('destination_id', $destinationID)
                    ->first(); 
            $ticketPriceId = $ticketPriceRecords->id;
            $startingFromPrice = $ticketPriceRecords->base_seat_fare;
            $departureTime = $ticketPriceRecords->dep_time;
            $arrivalTime = $ticketPriceRecords->arr_time;
            $depTime = date("H:i",strtotime($departureTime));
            $arrTime = date("H:i",strtotime($arrivalTime)); 
            $arr_time = new DateTime($arrivalTime);
            $dep_time = new DateTime($departureTime);
            $totalTravelTime = $dep_time->diff($arr_time);
            $totalJourneyTime = ($totalTravelTime->format("%a") * 24) + $totalTravelTime->format(" %h"). "h". $totalTravelTime->format(" %im");

            //$seatOpenDatas = $record->seatOpen;
            //$seatsOpenSeats = $seatOpenDatas->pluck('seatOpenSeats.id');
            //return $seatsOpenSeats;

            $totalSeats = $record->busSeats->where('ticket_price_id',$ticketPriceId)
                                            ->count('id');                      
            $seatDatas = $record->busSeats->where('ticket_price_id',$ticketPriceId)->all();
            $amenityDatas = $record->busAmenities;
            $amenityName = $amenityDatas->pluck('amenities.name');
            $amenityIcon = $amenityDatas->pluck('amenities.icon');
            $safetyDatas = $record->busSafety;
            $safetyName = $safetyDatas->pluck('safety.name');
            $safetyIcon = $safetyDatas->pluck('safety.icon');
            $busPhotoDatas = $record->busGallery;
            $busPhotos = $busPhotoDatas->pluck('image');
            $cSlabDatas = $record->cancellationslabs->cancellationSlabInfo;
            $cSlabDuration = $cSlabDatas->pluck('duration');
            $cSlabDeduction = $cSlabDatas->pluck('deduction');
        
             $seatClassRecords = 0;
             $sleeperClassRecords = 0;
            foreach($seatDatas as $seatData) {  
                 $seatclass = $seatData->seats->seat_class_id;
                 if($seatclass==1){
                     $seatClassRecords ++;
                 }
                 elseif($seatclass==2 || $seatclass==3){
                     $sleeperClassRecords ++;
                }
            }
           $bookedSeats = $this->getBookedSeats($sourceID,$destinationID,$entry_date,$busId);
           $seatClassRecords = $seatClassRecords - $bookedSeats[1];
           $sleeperClassRecords = $sleeperClassRecords - $bookedSeats[0];
           $totalSeats = $totalSeats - $bookedSeats[2];
           $ListingRecords[] = array(
                "busId" => $busId, 
                "busName" => $busName,
                "popularity" => $popularity,
                "busNumber" => $busNumber,
                "maxSeatBook" => $maxSeatBook,
                "conductor_number" => $conductor_number,
                "operatorId" => $operatorId,
                "operatorName" => $operatorName,
                "sittingType" => $sittingType,
                "busType" => $busType,
                "busTypeName" => $busTypeName,
                "totalSeats" => $totalSeats,
                "seaters" => $seatClassRecords,
                "sleepers" => $sleeperClassRecords,
                "startingFromPrice" => $startingFromPrice,
                "departureTime" =>$depTime,
                "arrivalTime" =>$arrTime,
                "totalJourneyTime" =>$totalJourneyTime,
                "amenityName" =>$amenityName,
                "amenityIcon" => $amenityIcon,
                "safetyIconName" =>$safetyName,
                "safetyIcon" => $safetyIcon,
                "busPhotos" => $busPhotos,
                "cancellationDuration" => $cSlabDuration,
                "cancellationDuduction" => $cSlabDeduction,
            );
                    
        }
        return $ListingRecords;
    }

 //Calculate Booked seats and remove it from total count
    public function getBookedSeats($sourceID,$destinationID,$entry_date,$busId){
        $booked = Config::get('constants.BOOKED_STATUS');
        $booked_seats = $this->booking->where('journey_dt',$entry_date)
            ->where('bus_id',$busId)
            ->where('source_id',$sourceID)
            ->where('destination_id',$destinationID)
            ->where('status',$booked)
            ->with(["bookingDetail.busSeats.seats"]) 
            ->get();
        $collection = collect($booked_seats);
        $i = 0;
        $seaterRecords = 0;
        $sleeperRecords = 0;
        foreach($collection as $cid){
        foreach($cid->bookingDetail as $cbd)
        {
            $class = $cbd->busSeats->seats->seat_class_id;
            if($class==1){
                $seaterRecords ++;
            }
            elseif($class==2 || $class==3){
                $sleeperRecords ++;
            }
        }
        $i++;
        } 
        $totalBookedCount= $sleeperRecords+$seaterRecords;
        return [$sleeperRecords,$seaterRecords,$totalBookedCount];

    }   
    public function getFilterOptions($request)
    {
        $sourceID = $request['sourceID'];
        $destinationID = $request['destinationID']; 

        $busTypes =  $this->busClass->get(['id','class_name']);
        $seatTypes = $this->seatClass->where('id',1)->orWhere('id',2)->get(['id','name']);
        $boardingPoints = $this->boardingDroping->where('location_id', $sourceID)->get(['id','boarding_point']);
        $dropingPoints = $this->boardingDroping->where('location_id', $destinationID)->get(['id','boarding_point']);
        $busOperator = $this->busOperator->get(['id','operator_name']);
        $amenities = $this->amenities->get(['id','name','icon']);

        $filterOptions[] = array(
           "busTypes" => $busTypes,
           "seatTypes" => $seatTypes,  
           "boardingPoints" => $boardingPoints,
           "dropingPoints"=> $dropingPoints,
           "busOperator"=>$busOperator,
           "amenities"=>$amenities   
        );
        return  $filterOptions;

    }

    public function filter($request)
    {   
        $booked = Config::get('constants.BOOKED_STATUS');   
        $price = $request['price'];
        $sourceID = $request['sourceID'];      
        $destinationID = $request['destinationID']; 
        $entry_date = $request['entry_date'];   
        if($sourceID==null ||  $destinationID==null || $entry_date==null)
            return ""; 
        $entry_date = date("Y-m-d", strtotime($entry_date));    
        $busType = $request['busType'];
        $seatType = $request['seatType'];    
        $boardingPointId = $request['boardingPointId'];
        $dropingingPointId = $request['dropingingPointId'];
        $operatorId = $request['operatorId'];
        $amenityId = $request['amenityId'];

        $busDetails = $this->ticketPrice
        ->where('source_id', $sourceID)
        ->where('destination_id', $destinationID)->get(['bus_id','start_j_days']);

        $records = array();
        $FilterRecords = array();

        foreach($busDetails as $busDetail){
            $busId = $busDetail['bus_id'];
            $jdays = $busDetail['start_j_days'];
            $busEntryPresent =$this->busSchedule->where('bus_id', $busId)
                                ->exists(); 
            if($busEntryPresent==true){
                $busScheduleDate = $this->busSchedule->whereIn('bus_id', (array)$busId)->pluck('id');
                $dates = $this->busScheduleDate
                    ->where('bus_schedule_id', $busScheduleDate)           
                    ->pluck('entry_date')->toarray();
                if($jdays>1){
                    $new_date = date('Y-m-d', strtotime('-1 day', strtotime($entry_date)));
                }else{
                    $new_date = $entry_date;
                }
                if(in_array($new_date, $dates))
                {
                    $records[] = $this->bus
                    ->with('busOperator')
                    ->with('busAmenities.amenities')
                    ->with('busSafety.safety')
                    ->with('BusType.busClass')
                    ->with('busSeats.seats')
                    ->with('BusSitting')
                    ->with('busGallery')
                    ->with('cancellationslabs.cancellationSlabInfo')
                    ->where('status','1')
                    ->where('id',$busId)
                    ->whereHas('busType.busClass', function ($query) use ($busType){
                        if($busType)
                        $query->whereIn('id', (array)$busType);            
                        })
                    ->whereHas('busSeats.seats.seatClass', function ($query) use ($seatType){
                        if($seatType)
                        $query->whereIn('id', (array)$seatType);            
                        })
                    ->whereHas('busStoppageTiming.boardingDroping', function ($query) use ($boardingPointId){  
                        if($boardingPointId)                   
                        $query->whereIn('id', (array)$boardingPointId);
                        })    
                    ->whereHas('busStoppageTiming.boardingDroping', function ($query) use ($dropingingPointId){
                        if($dropingingPointId)  
                        $query->whereIn('id', (array)$dropingingPointId);
                        })       
                    ->whereHas('busOperator', function ($query) use ($operatorId){
                        if($operatorId)
                        $query->whereIn('id', (array)$operatorId);            
                        })
                    ->whereHas('busAmenities.amenities', function ($query) use ($amenityId){
                        if($amenityId)
                        $query->whereIn('id', (array)$amenityId);            
                        })  
                    ->where('id',$busId)
                    ->get();
                } 
            }  
        }
        $records = Arr::flatten($records); 
        //return $records;
            foreach($records as $record){
                $busId = $record->id; 
                $busName = $record->name;
                $popularity = $record->popularity;
                $busNumber = $record->bus_number;
                $via = $record->via;
                $maxSeatBook = $record->max_seat_book;
                $conductor_number = $record->busContacts->phone;
                $operatorId = $record->busOperator->id;
                $operatorName = $record->busOperator->operator_name;
                $sittingType = $record->BusSitting->name;
                $busType = $record->BusType->busClass->class_name;
                $busTypeName = $record->BusType->name;
                $ticketPriceDatas = $record->ticketPrice;
                $ticketPriceRecords = $ticketPriceDatas
                ->where('source_id', $sourceID)
                ->where('destination_id', $destinationID)
                ->first(); 
                $ticketPriceId = $ticketPriceRecords->id;
                $startingFromPrice = $ticketPriceRecords->base_seat_fare;
                $departureTime = $ticketPriceRecords->dep_time;
                $arrivalTime = $ticketPriceRecords->arr_time;
                $depTime = date("H:i",strtotime($departureTime));
                $arrTime = date("H:i",strtotime($arrivalTime)); 
                $arr_time = new DateTime($arrivalTime);
                $dep_time = new DateTime($departureTime);
                $totalTravelTime = $dep_time->diff($arr_time);
                $totalJourneyTime = ($totalTravelTime->format("%a") * 24) + $totalTravelTime->format(" %h"). "h". $totalTravelTime->format(" %im");

                $totalSeats = $record->busSeats->where('ticket_price_id',$ticketPriceId)->count('id');

                $seatDatas = $record->busSeats->where('ticket_price_id',$ticketPriceId)->all();
                $amenityDatas = $record->busAmenities;
                $amenityName = $amenityDatas->pluck('amenities.name');
                $amenityIcon = $amenityDatas->pluck('amenities.icon');
                $safetyDatas = $record->busSafety;
                $safetyName = $safetyDatas->pluck('safety.name');
                $safetyIcon = $safetyDatas->pluck('safety.icon');
                $busPhotoDatas = $record->busGallery;
                $busPhotos = $busPhotoDatas->pluck('image');
                $cSlabDatas = $record->cancellationslabs->cancellationSlabInfo;
                $cSlabDuration = $cSlabDatas->pluck('duration');
                $cSlabDeduction = $cSlabDatas->pluck('deduction');
                $seatClassRecords = 0;
                $sleeperClassRecords = 0;
                foreach($seatDatas as $seatData) {  
                     $seatclass = $seatData->seats->seat_class_id;
                     if($seatclass==1){
                         $seatClassRecords ++;
                     }
                     elseif($seatclass==2 || $seatclass==3){
                         $sleeperClassRecords ++;
                    }
                }
                $bookedSeats = $this->getBookedSeats($sourceID,$destinationID,$entry_date,$busId);
                $seatClassRecords = $seatClassRecords - $bookedSeats[1];
                $sleeperClassRecords = $sleeperClassRecords - $bookedSeats[0];
                $totalSeats = $totalSeats - $bookedSeats[2];

                $FilterRecords[] = array(
                    "busId" => $busId, 
                    "busName" => $busName,
                    "popularity" => $popularity,
                    "busNumber" => $busNumber, 
                    "maxSeatBook" => $maxSeatBook,
                    "conductor_number" => $conductor_number,
                    "operatorId" => $operatorId,
                    "operatorName" => $operatorName,
                    "sittingType" => $sittingType,
                    "busType" => $busType,
                    "busTypeName" => $busTypeName,
                    "totalSeats" => $totalSeats,
                    "seaters" => $seatClassRecords,
                    "sleepers" => $sleeperClassRecords,
                    "startingFromPrice" => $startingFromPrice,
                    "departureTime" =>$depTime,
                    "arrivalTime" =>$arrTime,
                    "totalJourneyTime" =>$totalJourneyTime,
                    "amenityName" =>$amenityName,
                    "amenityIcon" => $amenityIcon, 
                    "safetyIconName" =>$safetyName,
                    "safetyIcon" => $safetyIcon,
                    "busPhotos" => $busPhotos,
                    "cancellationDuration" => $cSlabDuration,
                    "cancellationDuduction" => $cSlabDeduction,     
                );            
            }
            if($price == 0){
                $sorted = $FilterRecords;  
            }elseif($price == 1){
                $sortByPrice = collect($FilterRecords)->sortBy('startingFromPrice')->all();
                $sorted = $sortByPrice; 
           }  
           $sorted = array_values($sorted);
           return $sorted;   
    }

    public function busDetails($request)
    { 
        $busId = $request['bus_id'];
        $sourceID = $request['source_id'];      
        $destinationID = $request['destination_id']; 
        $result['busDetails'] = $this->bus->where('id',$busId)
                                ->with('cancellationslabs.cancellationSlabInfo')
                                ->with('busAmenities.amenities')
                                ->with('busSafety.safety')
                                ->with('busGallery')
                                ->get();        
        $result['boarding_point'] = $this->busStoppageTiming
                                              ->where('bus_id', $busId)
                                              ->where('location_id', $sourceID)
                                              ->get();
        $result['dropping_point'] = $this->busStoppageTiming
                                              ->where('bus_id', $busId)
                                              ->where('location_id', $destinationID)
                                              ->get();                                     

        return $result;
    }





}